import { createFileRoute } from "@tanstack/react-router";
import {
  isAuthenticated,
  json,
  loadConfig,
  readJsonBody,
  sameOrigin,
  saveConfig,
  storageConfigured,
} from "@/lib/admin-server";
import { sanitizeConfig } from "@/lib/site-config";

export const Route = createFileRoute("/api/admin/config")({
  server: {
    handlers: {
      // Full config (including unpublished posts) — admin only.
      GET: async ({ request }: { request: Request }) => {
        if (!(await isAuthenticated(request))) return json({ error: "Unauthorized." }, 401);
        try {
          return json({ config: await loadConfig(true), storage: storageConfigured() });
        } catch {
          return json({ error: "Could not read saved settings from storage." }, 502);
        }
      },

      // Save the whole config — admin only, same-origin only, re-validated server side.
      PUT: async ({ request }: { request: Request }) => {
        if (!sameOrigin(request)) return json({ error: "Forbidden." }, 403);
        if (!(await isAuthenticated(request))) return json({ error: "Unauthorized." }, 401);
        if (!storageConfigured()) {
          return json(
            { error: "Storage is not connected. Add the Upstash Redis variables in Vercel, then redeploy." },
            503,
          );
        }

        let body: unknown;
        try {
          body = await readJsonBody(request);
        } catch {
          return json({ error: "Bad request (invalid or oversized JSON)." }, 400);
        }

        const { config, errors, warnings } = sanitizeConfig((body as { config?: unknown })?.config);
        if (errors.length > 0) return json({ error: "Please fix the problems below.", errors, warnings }, 400);

        try {
          await saveConfig(config);
        } catch (e) {
          console.error("[trendpoptv] saveConfig failed:", (e as Error).message);
          return json({ error: "Could not save to storage. Try again." }, 502);
        }
        return json({ ok: true, config, warnings });
      },
    },
  },
});
