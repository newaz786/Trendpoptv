import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  LogOut,
  Lock,
  Megaphone,
  Pencil,
  Plus,
  Save,
  Settings as SettingsIcon,
  Star,
  Trash2,
  Type,
  Video,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DEFAULT_EMBED_HOSTS,
  LIMITS,
  parseIframeEmbed,
  parseImgEmbed,
  type Post,
  type SiteConfig,
  type SiteSettings,
} from "@/lib/site-config";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin" },
      { name: "robots", content: "noindex, nofollow, noarchive" },
      { name: "googlebot", content: "noindex, nofollow" },
    ],
  }),
  component: AdminPage,
});

// ───────────────────────── shared styles ─────────────────────────
const inputCls =
  "w-full rounded-xl border border-border bg-surface px-3 py-2 text-sm text-foreground shadow-soft outline-none transition-all placeholder:text-muted-foreground focus:border-ring focus:ring-2 focus:ring-ring/30";
const btnPrimary =
  "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50";
const btnGhost =
  "inline-flex items-center justify-center gap-2 rounded-full border border-border bg-surface px-3.5 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent disabled:opacity-50";
const cardCls = "rounded-2xl border border-border bg-card p-4 shadow-soft sm:p-5";

// ───────────────────────── api helper ─────────────────────────
interface ApiResult<T = Record<string, unknown>> {
  ok: boolean;
  status: number;
  body: T & { error?: string; errors?: string[]; warnings?: string[] };
}

async function api<T = Record<string, unknown>>(path: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const res = await fetch(path, {
      credentials: "same-origin",
      cache: "no-store",
      ...init,
      headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    });
    const body = (await res.json().catch(() => ({}))) as ApiResult<T>["body"];
    return { ok: res.ok, status: res.status, body };
  } catch {
    return {
      ok: false,
      status: 0,
      body: { error: "Network error. Check your connection." } as unknown as ApiResult<T>["body"],
    };
  }
}

type Phase = "loading" | "setup" | "login" | "ready";
type Tab = "posts" | "theme" | "adsense" | "settings";

function AdminPage() {
  const router = useRouter();
  const [phase, setPhase] = useState<Phase>("loading");
  const [setupReason, setSetupReason] = useState("");
  const [storageOk, setStorageOk] = useState(true);
  const [config, setConfig] = useState<SiteConfig | null>(null);
  const [savedJson, setSavedJson] = useState("");
  const [tab, setTab] = useState<Tab>("posts");
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ kind: "ok" | "err"; text: string; list?: string[] } | null>(null);

  const dirty = config !== null && JSON.stringify(config) !== savedJson;

  const loadConfig = useCallback(async () => {
    const r = await api<{ config: SiteConfig; storage: boolean }>("/api/admin/config");
    if (r.status === 401) {
      setPhase("login");
      return;
    }
    if (!r.ok || !r.body.config) {
      setNotice({ kind: "err", text: r.body.error || "Could not load settings." });
      return;
    }
    setConfig(r.body.config);
    setSavedJson(JSON.stringify(r.body.config));
    setStorageOk(r.body.storage !== false);
    setPhase("ready");
  }, []);

  useEffect(() => {
    (async () => {
      const r = await api<{ configured: boolean; reason?: string; storage: boolean; authenticated: boolean }>(
        "/api/admin/auth",
      );
      if (!r.ok) {
        setNotice({ kind: "err", text: r.body.error || "Could not reach the server." });
        setPhase("login");
        return;
      }
      setStorageOk(r.body.storage);
      if (!r.body.configured) {
        setSetupReason(r.body.reason || "");
        setPhase("setup");
      } else if (!r.body.authenticated) setPhase("login");
      else await loadConfig();
    })();
  }, [loadConfig]);

  // Warn before leaving with unsaved edits.
  useEffect(() => {
    if (!dirty) return;
    const h = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, [dirty]);

  const save = async () => {
    if (!config) return;
    setSaving(true);
    setNotice(null);
    const r = await api<{ config: SiteConfig }>("/api/admin/config", {
      method: "PUT",
      body: JSON.stringify({ config }),
    });
    setSaving(false);
    if (r.status === 401) {
      setPhase("login");
      setNotice({ kind: "err", text: "Your session expired. Sign in again — your edits are kept." });
      return;
    }
    if (!r.ok) {
      setNotice({ kind: "err", text: r.body.error || "Save failed.", list: r.body.errors });
      return;
    }
    setConfig(r.body.config);
    setSavedJson(JSON.stringify(r.body.config));
    setNotice({ kind: "ok", text: "Saved. Your site is updated.", list: r.body.warnings });
    await router.invalidate();
  };

  const logout = async () => {
    await api("/api/admin/auth", { method: "DELETE" });
    setConfig(null);
    setSavedJson("");
    setPhase("login");
  };

  if (phase === "loading") {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (phase === "setup") {
    return (
      <div className="mx-auto max-w-xl py-10">
        <div className={cardCls}>
          <h1 className="font-display text-xl font-semibold text-foreground">Admin is not set up yet</h1>
          <p className="mt-2 text-sm text-muted-foreground">{setupReason}</p>
          <p className="mt-3 text-sm text-foreground/80">
            In Vercel → Project → Settings → Environment Variables, add <code>ADMIN_PASSWORD</code> (12+ characters)
            and <code>ADMIN_SESSION_SECRET</code> (32+ random characters), then redeploy. See{" "}
            <code>.env.example</code> in the project for the full list.
          </p>
        </div>
      </div>
    );
  }

  if (phase === "login") {
    return (
      <LoginForm
        initialError={notice?.kind === "err" ? notice.text : ""}
        onSuccess={async () => {
          setNotice(null);
          await loadConfig();
        }}
      />
    );
  }

  if (!config) return null;

  const tabs: Array<{ id: Tab; label: string; Icon: typeof Video }> = [
    { id: "posts", label: "Videos", Icon: Video },
    { id: "theme", label: "Theme text", Icon: Type },
    { id: "adsense", label: "AdSense", Icon: Megaphone },
    { id: "settings", label: "Settings", Icon: SettingsIcon },
  ];

  return (
    <div className="mx-auto max-w-3xl space-y-4 pb-10">
      <div className="flex items-center justify-between gap-3 px-1">
        <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">Admin</h1>
        <button type="button" onClick={logout} className={btnGhost}>
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>

      {!storageOk && (
        <div className="flex gap-2 rounded-2xl border border-destructive/40 bg-destructive/10 p-3 text-sm text-foreground">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
          <span>
            Storage is not connected, so changes can’t be saved. Add <code>UPSTASH_REDIS_REST_URL</code> and{" "}
            <code>UPSTASH_REDIS_REST_TOKEN</code> in Vercel and redeploy.
          </span>
        </div>
      )}

      {/* Sticky save bar (sits under the 64px site header) */}
      <div className="sticky top-16 z-30 -mx-1 flex items-center justify-between gap-3 rounded-2xl border border-border bg-background/90 px-3 py-2 backdrop-blur-xl">
        <span className={cn("text-xs sm:text-sm", dirty ? "font-medium text-foreground" : "text-muted-foreground")}>
          {dirty ? "You have unsaved changes" : "All changes saved"}
        </span>
        <div className="flex gap-2">
          {dirty && (
            <button
              type="button"
              className={btnGhost}
              disabled={saving}
              onClick={() => {
                setConfig(JSON.parse(savedJson) as SiteConfig);
                setNotice(null);
              }}
            >
              Discard
            </button>
          )}
          <button type="button" className={btnPrimary} disabled={!dirty || saving || !storageOk} onClick={save}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save changes
          </button>
        </div>
      </div>

      {notice && (
        <div
          role="status"
          className={cn(
            "rounded-2xl border p-3 text-sm",
            notice.kind === "ok" ? "border-emerald-500/40 bg-emerald-500/10" : "border-destructive/40 bg-destructive/10",
          )}
        >
          <div className="flex items-start gap-2 text-foreground">
            {notice.kind === "ok" ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
            ) : (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            )}
            <span>{notice.text}</span>
          </div>
          {notice.list && notice.list.length > 0 && (
            <ul className="mt-2 list-disc space-y-1 pl-9 text-xs text-foreground/80">
              {notice.list.map((m, i) => (
                <li key={i}>{m}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {tabs.map(({ id, label, Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={cn(
              "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
              tab === id
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground/80 hover:bg-accent",
            )}
          >
            <Icon className="h-3.5 w-3.5" /> {label}
          </button>
        ))}
      </div>

      {tab === "posts" && <PostsTab config={config} setConfig={setConfig} />}
      {tab === "theme" && <ThemeTab config={config} setConfig={setConfig} />}
      {tab === "adsense" && <AdSenseTab config={config} setConfig={setConfig} />}
      {tab === "settings" && <SettingsTab config={config} setConfig={setConfig} />}
    </div>
  );
}

// ───────────────────────── login ─────────────────────────
function LoginForm({ onSuccess, initialError }: { onSuccess: () => void | Promise<void>; initialError?: string }) {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(initialError ?? "");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || busy) return;
    setBusy(true);
    setError("");
    const r = await api("/api/admin/auth", { method: "POST", body: JSON.stringify({ password }) });
    setBusy(false);
    if (r.ok) {
      setPassword("");
      await onSuccess();
    } else setError(r.body.error || "Sign-in failed.");
  };

  return (
    <div className="mx-auto max-w-sm py-12">
      <form onSubmit={submit} className={cn(cardCls, "space-y-4")} autoComplete="off">
        <div className="flex items-center gap-2">
          <Lock className="h-5 w-5 text-primary" />
          <h1 className="font-display text-xl font-semibold text-foreground">Admin sign-in</h1>
        </div>
        <label className="block text-sm font-medium text-foreground" htmlFor="admin-password">
          Password
        </label>
        <input
          id="admin-password"
          type="password"
          autoComplete="current-password"
          className={inputCls}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          maxLength={512}
          autoFocus
        />
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
        <button type="submit" className={cn(btnPrimary, "w-full")} disabled={busy || !password}>
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} Sign in
        </button>
      </form>
    </div>
  );
}

// ───────────────────────── small form helpers ─────────────────────────
interface TabProps {
  config: SiteConfig;
  setConfig: (c: SiteConfig) => void;
}

function Field({
  id,
  label,
  hint,
  children,
}: {
  id: string;
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex cursor-pointer items-center gap-2.5 text-sm text-foreground">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 rounded border-border accent-[var(--primary)]"
      />
      {label}
    </label>
  );
}

// ───────────────────────── posts tab ─────────────────────────
interface PostDraft {
  id: string;
  title: string;
  category: string;
  description: string;
  embedHtml: string;
  thumbnailHtml: string;
  published: boolean;
  featured: boolean;
  createdAt: number;
  isNew: boolean;
}

function newPostId(): string {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 12).toLowerCase();
}

function PostsTab({ config, setConfig }: TabProps) {
  const [draft, setDraft] = useState<PostDraft | null>(null);
  const sorted = useMemo(
    () => [...config.posts].sort((a, b) => Number(b.featured) - Number(a.featured) || b.createdAt - a.createdAt),
    [config.posts],
  );

  const startNew = () =>
    setDraft({
      id: newPostId(),
      title: "",
      category: "",
      description: "",
      embedHtml: "",
      thumbnailHtml: "",
      published: true,
      featured: false,
      createdAt: Date.now(),
      isNew: true,
    });

  const edit = (p: Post) =>
    setDraft({
      id: p.id,
      title: p.title,
      category: p.category,
      description: p.description,
      embedHtml: p.embedHtml,
      thumbnailHtml: p.thumbnailHtml,
      published: p.published,
      featured: p.featured,
      createdAt: p.createdAt,
      isNew: false,
    });

  const update = (id: string, patch: Partial<Post>) =>
    setConfig({ ...config, posts: config.posts.map((p) => (p.id === id ? { ...p, ...patch } : p)) });

  const remove = (p: Post) => {
    if (!window.confirm(`Delete “${p.title}”? This takes effect after you press Save changes.`)) return;
    setConfig({ ...config, posts: config.posts.filter((x) => x.id !== p.id) });
  };

  if (draft) {
    return (
      <PostEditor
        draft={draft}
        hosts={config.allowedEmbedHosts}
        onCancel={() => setDraft(null)}
        onDone={(post) => {
          const exists = config.posts.some((p) => p.id === post.id);
          setConfig({
            ...config,
            posts: exists ? config.posts.map((p) => (p.id === post.id ? post : p)) : [post, ...config.posts],
          });
          setDraft(null);
        }}
      />
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3 px-1">
        <p className="text-sm text-muted-foreground">
          {config.posts.length} video{config.posts.length === 1 ? "" : "s"}
        </p>
        <button type="button" className={btnPrimary} onClick={startNew}>
          <Plus className="h-4 w-4" /> Add video
        </button>
      </div>

      {sorted.length === 0 && (
        <div className={cn(cardCls, "text-center text-sm text-muted-foreground")}>
          No videos yet. Press “Add video”, paste the HTML embed code of your video and its thumbnail, then Save.
        </div>
      )}

      {sorted.map((p) => {
        const thumb = parseImgEmbed(p.thumbnailHtml);
        return (
          <div key={p.id} className={cn(cardCls, "flex gap-3 !p-3")}>
            <div className="relative h-16 w-28 shrink-0 overflow-hidden rounded-xl bg-muted sm:h-20 sm:w-36">
              {thumb.ok && (
                <img src={thumb.src} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="line-clamp-2 text-sm font-medium leading-snug text-foreground">{p.title}</p>
              <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px]">
                {!p.published && (
                  <span className="rounded-full bg-muted px-2 py-0.5 font-medium text-muted-foreground">Hidden</span>
                )}
                {p.featured && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 font-medium text-amber-600 dark:text-amber-300">
                    <Star className="h-3 w-3" /> Featured
                  </span>
                )}
                {p.category && <span className="text-muted-foreground">{p.category}</span>}
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button type="button" className={cn(btnGhost, "!px-2.5 !py-1 text-xs")} onClick={() => edit(p)}>
                  <Pencil className="h-3 w-3" /> Edit
                </button>
                <button
                  type="button"
                  className={cn(btnGhost, "!px-2.5 !py-1 text-xs")}
                  onClick={() => update(p.id, { published: !p.published })}
                >
                  {p.published ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                  {p.published ? "Hide" : "Publish"}
                </button>
                <button
                  type="button"
                  className={cn(btnGhost, "!px-2.5 !py-1 text-xs text-destructive")}
                  onClick={() => remove(p)}
                >
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function PostEditor({
  draft: initial,
  hosts,
  onCancel,
  onDone,
}: {
  draft: PostDraft;
  hosts: string[];
  onCancel: () => void;
  onDone: (p: Post) => void;
}) {
  const [d, setD] = useState(initial);
  const [touched, setTouched] = useState(false);
  const set = <K extends keyof PostDraft>(k: K, v: PostDraft[K]) => setD((x) => ({ ...x, [k]: v }));

  const embed = useMemo(() => parseIframeEmbed(d.embedHtml, hosts), [d.embedHtml, hosts]);
  const thumb = useMemo(() => parseImgEmbed(d.thumbnailHtml), [d.thumbnailHtml]);
  const titleOk = d.title.trim().length > 0;
  const canSave = titleOk && embed.ok && thumb.ok;

  const submit = () => {
    setTouched(true);
    if (!canSave || !embed.ok || !thumb.ok) return;
    onDone({
      id: d.id,
      title: d.title.trim().slice(0, LIMITS.title),
      category: d.category.trim().slice(0, LIMITS.category),
      description: d.description.trim().slice(0, LIMITS.description),
      embedHtml: embed.canonical,
      embedSrc: embed.src,
      embedTitle: embed.title,
      thumbnailHtml: thumb.canonical,
      thumbnailSrc: thumb.src,
      published: d.published,
      featured: d.featured,
      createdAt: d.createdAt,
    });
  };

  return (
    <div className={cn(cardCls, "space-y-4")}>
      <h2 className="font-display text-lg font-semibold text-foreground">{d.isNew ? "Add video" : "Edit video"}</h2>

      <Field id="p-title" label="Title">
        <input
          id="p-title"
          className={inputCls}
          value={d.title}
          maxLength={LIMITS.title}
          onChange={(e) => set("title", e.target.value)}
        />
        {touched && !titleOk && <p className="text-xs text-destructive">Title is required.</p>}
      </Field>

      <Field id="p-cat" label="Category / channel (optional)">
        <input
          id="p-cat"
          className={inputCls}
          value={d.category}
          maxLength={LIMITS.category}
          onChange={(e) => set("category", e.target.value)}
        />
      </Field>

      <Field id="p-desc" label="Description (optional)">
        <textarea
          id="p-desc"
          rows={4}
          className={inputCls}
          value={d.description}
          maxLength={LIMITS.description}
          onChange={(e) => set("description", e.target.value)}
        />
      </Field>

      <Field
        id="p-embed"
        label="Video — HTML embed code"
        hint="Paste the <iframe …></iframe> code from your video host. Only the iframe is kept; scripts and other markup are discarded."
      >
        <textarea
          id="p-embed"
          rows={4}
          spellCheck={false}
          className={cn(inputCls, "font-mono text-xs")}
          placeholder='<iframe src="https://www.youtube.com/embed/…" allowfullscreen></iframe>'
          value={d.embedHtml}
          onChange={(e) => set("embedHtml", e.target.value)}
        />
        {d.embedHtml.trim() && !embed.ok && <p className="text-xs text-destructive">{embed.error}</p>}
        {embed.ok && (
          <div className="space-y-1.5">
            <p className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="h-3.5 w-3.5" /> Valid embed
              {embed.ignoredExtra ? " (extra markup will be removed)" : ""}
            </p>
            <div className="aspect-video w-full overflow-hidden rounded-xl bg-black">
              <iframe
                src={embed.src}
                title="Preview"
                className="h-full w-full border-0"
                loading="lazy"
                allow="encrypted-media; picture-in-picture; fullscreen"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
                sandbox="allow-scripts allow-same-origin allow-presentation allow-popups allow-forms"
              />
            </div>
          </div>
        )}
        {touched && !d.embedHtml.trim() && <p className="text-xs text-destructive">Video embed code is required.</p>}
      </Field>

      <Field
        id="p-thumb"
        label="Thumbnail — HTML embed code"
        hint="Paste the <img src=&quot;https://…&quot;> code for the thumbnail. Only the image URL and alt text are kept."
      >
        <textarea
          id="p-thumb"
          rows={3}
          spellCheck={false}
          className={cn(inputCls, "font-mono text-xs")}
          placeholder='<img src="https://…/thumbnail.jpg" alt="…">'
          value={d.thumbnailHtml}
          onChange={(e) => set("thumbnailHtml", e.target.value)}
        />
        {d.thumbnailHtml.trim() && !thumb.ok && <p className="text-xs text-destructive">{thumb.error}</p>}
        {thumb.ok && (
          <div className="aspect-video w-full max-w-xs overflow-hidden rounded-xl bg-muted">
            <img src={thumb.src} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
          </div>
        )}
        {touched && !d.thumbnailHtml.trim() && (
          <p className="text-xs text-destructive">Thumbnail embed code is required.</p>
        )}
      </Field>

      <div className="flex flex-wrap gap-x-6 gap-y-2">
        <Toggle checked={d.published} onChange={(v) => set("published", v)} label="Published (visible on the site)" />
        <Toggle checked={d.featured} onChange={(v) => set("featured", v)} label="Featured (shown first)" />
      </div>

      <div className="flex justify-end gap-2 pt-1">
        <button type="button" className={btnGhost} onClick={onCancel}>
          Cancel
        </button>
        <button type="button" className={btnPrimary} onClick={submit}>
          {d.isNew ? "Add to list" : "Apply"}
        </button>
      </div>
      <p className="text-xs text-muted-foreground">
        This updates the list below. Press <strong>Save changes</strong> at the top to publish it to your site.
      </p>
    </div>
  );
}

// ───────────────────────── theme text tab ─────────────────────────
const THEME_FIELDS: Array<{
  key: keyof Pick<
    SiteSettings,
    "name" | "tagline" | "metaTitle" | "metaDescription" | "keywords" | "heroTitle" | "heroSubtitle" | "aboutText" | "footerText"
  >;
  label: string;
  max: number;
  rows?: number;
  hint?: string;
}> = [
  { key: "name", label: "Site name", max: 40, hint: "Shown in the header, About window, browser tab and search results." },
  { key: "tagline", label: "Tagline", max: LIMITS.shortText },
  { key: "heroTitle", label: "Home page heading", max: 80 },
  { key: "heroSubtitle", label: "Home page sub-heading", max: LIMITS.shortText },
  { key: "aboutText", label: "About window text", max: LIMITS.longText, rows: 4 },
  { key: "footerText", label: "Footer text", max: LIMITS.shortText },
  { key: "metaTitle", label: "SEO title", max: 120, hint: "Browser tab title and search-result headline." },
  { key: "metaDescription", label: "SEO description", max: 320, rows: 3 },
  { key: "keywords", label: "SEO keywords", max: 400, rows: 2, hint: "Comma-separated." },
];

function ThemeTab({ config, setConfig }: TabProps) {
  const s = config.site;
  const setSite = (patch: Partial<SiteSettings>) => setConfig({ ...config, site: { ...s, ...patch } });
  const logo = useMemo(() => (s.logoHtml.trim() ? parseImgEmbed(s.logoHtml) : null), [s.logoHtml]);
  const colorValid = /^#[0-9a-fA-F]{6}$/.test(s.primaryColor);

  return (
    <div className={cn(cardCls, "space-y-4")}>
      {THEME_FIELDS.map((f) => (
        <Field key={f.key} id={`t-${f.key}`} label={f.label} hint={f.hint}>
          {f.rows ? (
            <textarea
              id={`t-${f.key}`}
              rows={f.rows}
              className={inputCls}
              maxLength={f.max}
              value={s[f.key]}
              onChange={(e) => setSite({ [f.key]: e.target.value } as Partial<SiteSettings>)}
            />
          ) : (
            <input
              id={`t-${f.key}`}
              className={inputCls}
              maxLength={f.max}
              value={s[f.key]}
              onChange={(e) => setSite({ [f.key]: e.target.value } as Partial<SiteSettings>)}
            />
          )}
        </Field>
      ))}

      <Field
        id="t-color"
        label="Accent colour (optional)"
        hint="Leave empty to keep the built-in violet theme. Pick a mid-to-dark colour so white text stays readable."
      >
        <div className="flex items-center gap-2">
          <input
            type="color"
            aria-label="Pick accent colour"
            value={colorValid ? s.primaryColor : "#7c3aed"}
            onChange={(e) => setSite({ primaryColor: e.target.value })}
            className="h-10 w-12 cursor-pointer rounded-lg border border-border bg-surface p-1"
          />
          <input
            id="t-color"
            className={inputCls}
            placeholder="#7c3aed"
            maxLength={7}
            value={s.primaryColor}
            onChange={(e) => setSite({ primaryColor: e.target.value.trim() })}
          />
          {s.primaryColor && (
            <button type="button" className={btnGhost} onClick={() => setSite({ primaryColor: "" })}>
              Reset
            </button>
          )}
        </div>
        {s.primaryColor && !colorValid && <p className="text-xs text-destructive">Use the form #rrggbb.</p>}
      </Field>

      <Field
        id="t-logo"
        label="Logo — HTML embed code (optional)"
        hint="Paste an <img …> tag. Leave empty to show the site name as a text logo."
      >
        <textarea
          id="t-logo"
          rows={2}
          spellCheck={false}
          className={cn(inputCls, "font-mono text-xs")}
          placeholder='<img src="https://…/logo.png" alt="Logo">'
          value={s.logoHtml}
          onChange={(e) => setSite({ logoHtml: e.target.value })}
        />
        {logo && !logo.ok && <p className="text-xs text-destructive">{logo.error}</p>}
        {logo?.ok && (
          <img src={logo.src} alt="" referrerPolicy="no-referrer" className="h-12 w-auto max-w-full rounded-lg bg-muted p-1" />
        )}
      </Field>
    </div>
  );
}

// ───────────────────────── AdSense tab ─────────────────────────
function AdSenseTab({ config, setConfig }: TabProps) {
  const a = config.adsense;
  const set = (patch: Partial<typeof a>) => setConfig({ ...config, adsense: { ...a, ...patch } });
  const pubOk = /^(ca-)?pub-\d{10,20}$/i.test(a.publisherId.trim());

  return (
    <div className={cn(cardCls, "space-y-4")}>
      <Toggle checked={a.enabled} onChange={(v) => set({ enabled: v })} label="Show Google AdSense on the site" />

      <Field
        id="a-pub"
        label="Publisher ID"
        hint="Looks like ca-pub-1234567890123456 (AdSense → Account → Settings → Account information)."
      >
        <input
          id="a-pub"
          className={inputCls}
          placeholder="ca-pub-1234567890123456"
          value={a.publisherId}
          maxLength={40}
          onChange={(e) => set({ publisherId: e.target.value.trim() })}
        />
        {a.publisherId && !pubOk && <p className="text-xs text-destructive">That doesn’t look like a publisher ID.</p>}
      </Field>

      <div className="grid gap-4 sm:grid-cols-3">
        <Field id="a-home" label="Home page ad slot ID" hint="Display ad unit, numeric.">
          <input
            id="a-home"
            inputMode="numeric"
            className={inputCls}
            value={a.slotHome}
            maxLength={20}
            onChange={(e) => set({ slotHome: e.target.value.trim() })}
          />
        </Field>
        <Field id="a-watch" label="Watch page ad slot ID">
          <input
            id="a-watch"
            inputMode="numeric"
            className={inputCls}
            value={a.slotWatch}
            maxLength={20}
            onChange={(e) => set({ slotWatch: e.target.value.trim() })}
          />
        </Field>
        <Field id="a-post" label="Video page ad slot ID">
          <input
            id="a-post"
            inputMode="numeric"
            className={inputCls}
            value={a.slotPost}
            maxLength={20}
            onChange={(e) => set({ slotPost: e.target.value.trim() })}
          />
        </Field>
      </div>

      <div className="rounded-xl bg-muted/60 p-3 text-xs leading-relaxed text-muted-foreground">
        <p>
          • When enabled, the AdSense script is added to every public page and <code>/ads.txt</code> is generated
          automatically from your publisher ID.
        </p>
        <p className="mt-1">
          • Empty slot ID = no manual ad unit in that place. “Auto ads” are controlled inside your AdSense account, not
          here — exclude <code>/admin</code> there.
        </p>
        <p className="mt-1">
          • AdSense policy requires that you have the rights to the videos you embed and show them in a way the host
          allows.
        </p>
      </div>
    </div>
  );
}

// ───────────────────────── settings tab ─────────────────────────
function SettingsTab({ config, setConfig }: TabProps) {
  const s = config.site;
  return (
    <div className={cn(cardCls, "space-y-4")}>
      <Field
        id="s-hosts"
        label="Allowed video embed hosts"
        hint="One domain per line. An embed is only accepted if its iframe src is on one of these domains (subdomains included). This is what stops a bad paste from loading an unknown site."
      >
        <textarea
          id="s-hosts"
          key={config.allowedEmbedHosts.join(",")}
          rows={9}
          spellCheck={false}
          className={cn(inputCls, "font-mono text-xs")}
          defaultValue={config.allowedEmbedHosts.join("\n")}
          onBlur={(e) =>
            setConfig({
              ...config,
              allowedEmbedHosts: e.target.value
                .split(/\r?\n/)
                .map((h) => h.trim())
                .filter(Boolean),
            })
          }
        />
        <button
          type="button"
          className={cn(btnGhost, "mt-1 !px-3 !py-1 text-xs")}
          onClick={() => setConfig({ ...config, allowedEmbedHosts: DEFAULT_EMBED_HOSTS })}
        >
          Restore default list
        </button>
      </Field>

      <Field
        id="s-url"
        label="Public site URL"
        hint="Used for the canonical link and social-share previews, e.g. https://trendpoptv.com"
      >
        <input
          id="s-url"
          className={inputCls}
          placeholder="https://your-domain.com"
          value={s.siteUrl}
          maxLength={200}
          onChange={(e) => setConfig({ ...config, site: { ...s, siteUrl: e.target.value.trim() } })}
        />
      </Field>

      <div className="rounded-xl bg-muted/60 p-3 text-xs leading-relaxed text-muted-foreground">
        <p>
          <strong className="text-foreground">Changing the admin password:</strong> edit <code>ADMIN_PASSWORD</code> in
          Vercel and redeploy. To sign out every device immediately, change <code>ADMIN_SESSION_SECRET</code> too.
        </p>
        <p className="mt-1">Sessions last 8 hours. After 8 wrong passwords an IP is blocked for 15 minutes.</p>
      </div>
    </div>
  );
}
