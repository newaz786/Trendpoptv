import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { Header, SideRail, MobileTabBar } from "@/components/Header";
import { PlayerHost } from "@/components/PlayerHost";
import { getSiteConfig } from "@/lib/site.functions";
import { useSiteConfig } from "@/lib/use-site";
import { DEFAULT_PUBLIC_CONFIG, adsenseActive } from "@/lib/site-config";

function NotFoundComponent() {
  const { site } = useSiteConfig();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-soft transition-colors hover:bg-primary/90"
          >
            Back to {site.name}
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  // Public site settings (theme text, AdSense ids, published posts). Cached on
  // the client for a minute; the admin panel calls router.invalidate() after saving.
  loader: async () => ({ config: await getSiteConfig() }),
  staleTime: 60_000,
  head: ({ loaderData }) => {
    const cfg = loaderData?.config ?? DEFAULT_PUBLIC_CONFIG;
    const s = cfg.site;
    const origin = s.siteUrl.replace(/\/+$/, "");
    const ogImage = `${origin}/og-image.jpg`;
    const themeColor = s.primaryColor || "#7C3AED";
    const adsOn = adsenseActive(cfg.adsense);
    return {
      meta: [
        // ───── Core ─────
        { charSet: "utf-8" },
        { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
        { httpEquiv: "X-UA-Compatible", content: "IE=edge" },
        { name: "theme-color", content: themeColor },
        { name: "color-scheme", content: "light dark" },
        { title: s.metaTitle },
        { name: "description", content: s.metaDescription },
        { name: "keywords", content: s.keywords },
        { name: "author", content: "Anya" },
        { name: "creator", content: "Anya" },
        { name: "publisher", content: s.name },
        { name: "copyright", content: s.name },
        { name: "rating", content: "general" },
        { name: "referrer", content: "strict-origin-when-cross-origin" },

        // ───── Search engines ─────
        { name: "robots", content: "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" },
        { name: "googlebot", content: "index, follow, max-image-preview:large, max-snippet:-1" },
        { name: "bingbot", content: "index, follow" },
        { name: "google", content: "notranslate" },
        { name: "google-site-verification", content: "" },
        // Lets Google associate this site with your AdSense account.
        ...(adsOn ? [{ name: "google-adsense-account", content: cfg.adsense.publisherId }] : []),

        // ───── PWA / App ─────
        { name: "application-name", content: s.name },
        { name: "apple-mobile-web-app-title", content: s.name },
        { name: "apple-mobile-web-app-capable", content: "yes" },
        { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
        { name: "mobile-web-app-capable", content: "yes" },
        { name: "format-detection", content: "telephone=no" },
        { name: "HandheldFriendly", content: "true" },
        { name: "MobileOptimized", content: "320" },

        // ───── Microsoft / Windows tiles ─────
        { name: "msapplication-TileColor", content: themeColor },
        { name: "msapplication-TileImage", content: "/chiku.png" },
        { name: "msapplication-config", content: "/browserconfig.xml" },
        { name: "msapplication-tap-highlight", content: "no" },

        // ───── Open Graph (Facebook, LinkedIn, WhatsApp, Discord, Telegram, Slack, iMessage) ─────
        { property: "og:site_name", content: s.name },
        { property: "og:title", content: s.metaTitle },
        { property: "og:description", content: s.metaDescription },
        { property: "og:type", content: "website" },
        { property: "og:url", content: origin },
        { property: "og:image", content: ogImage },
        { property: "og:image:secure_url", content: ogImage },
        { property: "og:image:type", content: "image/jpeg" },
        { property: "og:image:width", content: "1200" },
        { property: "og:image:height", content: "630" },
        { property: "og:image:alt", content: `${s.name} — ${s.tagline}` },
        { property: "og:locale", content: "en_US" },

        // ───── Twitter / X ─────
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:site", content: "@itzAnya" },
        { name: "twitter:creator", content: "@itzAnya" },
        { name: "twitter:title", content: s.metaTitle },
        { name: "twitter:description", content: s.metaDescription },
        { name: "twitter:image", content: ogImage },
        { name: "twitter:image:alt", content: `${s.name} — ${s.tagline}` },

        // ───── Pinterest ─────
        { name: "pinterest", content: "nopin" },
        { name: "pinterest-rich-pin", content: "true" },

        // ───── Facebook (optional app id) ─────
        { property: "fb:app_id", content: "" },

        // ───── Discord / Slack (use OG above; theme-color drives embed accent) ─────
      ],
      links: [
        { rel: "stylesheet", href: appCss },
        { rel: "canonical", href: `${origin}/` },
        { rel: "manifest", href: "/manifest.json" },
        { rel: "icon", type: "image/png", href: "/chiku.png" },
        { rel: "shortcut icon", type: "image/png", href: "/chiku.png" },
        { rel: "apple-touch-icon", href: "/chiku.png" },
        { rel: "apple-touch-icon", sizes: "192x192", href: "/chiku.png" },
        { rel: "apple-touch-icon", sizes: "512x512", href: "/chiku.png" },
        { rel: "mask-icon", href: "/chiku.png", color: themeColor },
        { rel: "preconnect", href: "https://fonts.googleapis.com" },
        { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
        {
          rel: "stylesheet",
          href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap",
        },
      ],
      scripts: [
        {
          type: "application/ld+json",
          // "<" escaped so admin-edited text can never close the script element.
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            name: s.name,
            description: s.metaDescription,
            applicationCategory: "MultimediaApplication",
            operatingSystem: "Any",
            offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
            author: {
              "@type": "Person",
              name: "Anya",
              url: "https://github.com/itz-Anya",
            },
          }).replace(/</g, "\\u003c"),
        },
        // Google AdSense loader (only when enabled + valid publisher id in the admin panel).
        ...(adsOn
          ? [
              {
                src: `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${cfg.adsense.publisherId}`,
                async: true,
                crossOrigin: "anonymous" as const,
              },
            ]
          : []),
      ],
    };
  },
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { site } = useSiteConfig();
  // Optional admin-chosen accent colour. Re-validated here so only a plain
  // #rrggbb value can ever reach the stylesheet.
  const accent = /^#[0-9a-fA-F]{6}$/.test(site.primaryColor) ? site.primaryColor : "";
  return (
    <div className="min-h-screen overflow-x-hidden bg-background">
      {accent && (
        <style
          dangerouslySetInnerHTML={{
            __html: `:root,.dark{--primary:${accent};--ring:${accent}}`,
          }}
        />
      )}
      <Header />
      <div className="mx-auto flex max-w-[1600px] gap-2 px-3 sm:px-4 lg:px-6">
        <SideRail />
        <main className="min-w-0 flex-1 pb-24 pt-4 sm:pt-6 lg:pb-12">
          <Outlet />
          {site.footerText && (
            <footer className="mt-12 border-t border-border/60 pt-6 text-center text-xs text-muted-foreground">
              {site.footerText}
            </footer>
          )}
        </main>
      </div>
      <MobileTabBar />
      <PlayerHost />
    </div>
  );
}
