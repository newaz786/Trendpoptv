import { createFileRoute } from "@tanstack/react-router";
import {
  adminConfigured,
  allowLoginAttempt,
  checkPassword,
  clearLoginAttempts,
  clearSessionCookie,
  clientIp,
  createSessionCookie,
  isAuthenticated,
  json,
  readJsonBody,
  sameOrigin,
  sleep,
  storageConfigured,
} from "@/lib/admin-server";

export const Route = createFileRoute("/api/admin/auth")({
  server: {
    handlers: {
      // Session status — used by the admin page to decide between login / dashboard.
      GET: async ({ request }: { request: Request }) => {
        const cfg = adminConfigured();
        return json({
          configured: cfg.ok,
          reason: cfg.ok ? undefined : cfg.reason,
          storage: storageConfigured(),
          authenticated: cfg.ok ? await isAuthenticated(request) : false,
        });
      },

      // Login
      POST: async ({ request }: { request: Request }) => {
        if (!sameOrigin(request)) return json({ error: "Forbidden." }, 403);
        const cfg = adminConfigured();
        if (!cfg.ok) return json({ error: cfg.reason }, 503);

        const ip = clientIp(request);
        if (!(await allowLoginAttempt(ip))) {
          return json({ error: "Too many attempts. Try again in 15 minutes." }, 429, { "Retry-After": "900" });
        }

        let password = "";
        try {
          const body = (await readJsonBody(request, 4096)) as { password?: unknown };
          password = typeof body.password === "string" ? body.password : "";
        } catch {
          return json({ error: "Bad request." }, 400);
        }

        if (!(await checkPassword(password))) {
          await sleep(600); // slow down guessing
          return json({ error: "Incorrect password." }, 401);
        }

        await clearLoginAttempts(ip);
        return json({ ok: true }, 200, { "Set-Cookie": await createSessionCookie(request) });
      },

      // Logout
      DELETE: async ({ request }: { request: Request }) => {
        if (!sameOrigin(request)) return json({ error: "Forbidden." }, 403);
        return json({ ok: true }, 200, { "Set-Cookie": clearSessionCookie(request) });
      },
    },
  },
});
