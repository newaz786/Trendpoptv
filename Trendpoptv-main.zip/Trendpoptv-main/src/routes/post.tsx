import { createFileRoute, Link } from "@tanstack/react-router";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { useEffect } from "react";
import { AlertCircle } from "lucide-react";
import { AdSlot } from "@/components/AdSlot";
import { PostCard } from "@/components/PostCard";
import { configFromHead, useSiteConfig } from "@/lib/use-site";
import { useChiku } from "@/lib/store";

const postSearch = z.object({
  id: fallback(z.string(), "").default(""),
});

export const Route = createFileRoute("/post")({
  validateSearch: zodValidator(postSearch),
  head: (ctx) => {
    const cfg = configFromHead(ctx);
    const id = (ctx as { match?: { search?: { id?: string } } }).match?.search?.id ?? "";
    const post = cfg.posts.find((p) => p.id === id);
    const name = cfg.site.name;
    if (!post) return { meta: [{ title: `Video not found — ${name}` }] };
    const description = (post.description || cfg.site.metaDescription).slice(0, 200);
    const ld = {
      "@context": "https://schema.org",
      "@type": "VideoObject",
      name: post.title,
      description,
      thumbnailUrl: post.thumbnailSrc,
      uploadDate: new Date(post.createdAt).toISOString(),
      embedUrl: post.embedSrc,
    };
    return {
      meta: [
        { title: `${post.title} — ${name}` },
        { name: "description", content: description },
        { property: "og:title", content: post.title },
        { property: "og:description", content: description },
        { property: "og:type", content: "video.other" },
        { property: "og:image", content: post.thumbnailSrc },
      ],
      scripts: [
        {
          type: "application/ld+json",
          // "<" escaped so the JSON can never close the script element.
          children: JSON.stringify(ld).replace(/</g, "\\u003c"),
        },
      ],
    };
  },
  component: PostPage,
});

function PostPage() {
  const { id } = Route.useSearch();
  const { posts, site } = useSiteConfig();
  const closePlayer = useChiku((s) => s.closePlayer);
  const hasPlayer = useChiku((s) => !!s.player.video);
  const post = posts.find((p) => p.id === id);
  const others = posts.filter((p) => p.id !== id).slice(0, 12);

  // Stop the floating stream player so two videos never play at once.
  useEffect(() => {
    if (hasPlayer) closePlayer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!post) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 py-20 text-center">
        <AlertCircle className="h-10 w-10 text-destructive" />
        <h1 className="font-display text-xl font-semibold text-foreground">This video isn't available</h1>
        <p className="text-sm text-muted-foreground">It may have been unpublished or the link is incorrect.</p>
        <Link
          to="/"
          className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
        >
          Back to {site.name}
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="min-w-0">
        <div className="aspect-video w-full overflow-hidden rounded-2xl bg-black">
          <iframe
            key={post.id}
            src={post.embedSrc}
            title={post.embedTitle || post.title}
            className="h-full w-full border-0"
            allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowFullScreen
            loading="lazy"
            referrerPolicy="strict-origin-when-cross-origin"
            sandbox="allow-scripts allow-same-origin allow-presentation allow-popups allow-forms"
          />
        </div>

        <div className="mt-4 px-1">
          <h1 className="font-display text-xl font-semibold leading-tight tracking-tight text-foreground sm:text-2xl">
            {post.title}
          </h1>
          <p className="mt-2 text-xs text-muted-foreground">
            {[post.category, new Date(post.createdAt).toLocaleDateString()].filter(Boolean).join(" • ")}
          </p>
          {post.description && (
            <p className="mt-4 whitespace-pre-wrap break-words text-sm leading-relaxed text-foreground/85">
              {post.description}
            </p>
          )}
        </div>

        <AdSlot placement="post" />
      </div>

      <aside className="space-y-4">
        {others.length > 0 && (
          <>
            <h2 className="px-1 font-display text-base font-semibold tracking-tight text-foreground">
              More from {site.name}
            </h2>
            <div className="grid grid-cols-2 gap-x-3 gap-y-5 lg:grid-cols-1">
              {others.map((p, i) => (
                <PostCard key={p.id} post={p} index={i} />
              ))}
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
