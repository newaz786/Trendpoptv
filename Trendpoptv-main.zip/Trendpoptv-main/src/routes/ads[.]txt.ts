import { createFileRoute } from "@tanstack/react-router";
import { loadConfig } from "@/lib/admin-server";
import { adsenseActive, buildAdsTxt } from "@/lib/site-config";

// Serves /ads.txt from the AdSense publisher ID saved in the admin panel.
export const Route = createFileRoute("/ads.txt")({
  server: {
    handlers: {
      GET: async () => {
        const { adsense } = await loadConfig();
        const body = adsenseActive(adsense) ? buildAdsTxt(adsense.publisherId) : "# AdSense is not enabled.\n";
        return new Response(body, {
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "Cache-Control": "public, max-age=300",
            "X-Content-Type-Options": "nosniff",
          },
        });
      },
    },
  },
});
