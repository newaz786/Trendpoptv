// Trendpoptv — shared site configuration.
//
// Pure TypeScript with NO imports so it can run on the server (admin API, SSR)
// and in the browser (admin live preview). Everything an admin types is
// validated/sanitised here; the rest of the app only ever renders the
// *derived, sanitised* fields (embedSrc, thumbnailSrc, logoSrc), never raw HTML.

export const DEFAULT_SITE_NAME = "Trendpoptv";

export const DEFAULT_EMBED_HOSTS = [
  "youtube.com",
  "youtube-nocookie.com",
  "youtu.be",
  "vimeo.com",
  "dailymotion.com",
  "streamable.com",
  "rumble.com",
  "twitch.tv",
  "facebook.com",
  "ok.ru",
  "archive.org",
  "drive.google.com",
];

export interface SiteSettings {
  name: string;
  tagline: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string;
  heroTitle: string;
  heroSubtitle: string;
  aboutText: string;
  footerText: string;
  /** Optional #RRGGBB override for the primary/accent colour. "" = built-in theme. */
  primaryColor: string;
  /** Public site URL (no trailing slash). Used for canonical / OpenGraph. */
  siteUrl: string;
  /** Optional logo, entered as an HTML <img> embed. "" = text wordmark. */
  logoHtml: string;
  /** Derived from logoHtml. Never set by the client. */
  logoSrc: string;
}

export interface AdSenseSettings {
  enabled: boolean;
  /** e.g. ca-pub-1234567890123456 */
  publisherId: string;
  slotHome: string;
  slotWatch: string;
  slotPost: string;
}

export interface Post {
  id: string;
  title: string;
  category: string;
  description: string;
  /** Canonical iframe markup rebuilt by the server from the pasted embed code. */
  embedHtml: string;
  /** Canonical <img> markup rebuilt by the server from the pasted thumbnail code. */
  thumbnailHtml: string;
  /** Derived, validated https URL for the player iframe. */
  embedSrc: string;
  embedTitle: string;
  /** Derived, validated https URL (or /path) for the thumbnail. */
  thumbnailSrc: string;
  published: boolean;
  featured: boolean;
  createdAt: number;
}

export interface SiteConfig {
  version: 1;
  site: SiteSettings;
  adsense: AdSenseSettings;
  allowedEmbedHosts: string[];
  posts: Post[];
}

/** What anonymous visitors receive: published posts only, no admin-only fields. */
export interface PublicPost {
  id: string;
  title: string;
  category: string;
  description: string;
  embedSrc: string;
  embedTitle: string;
  thumbnailSrc: string;
  featured: boolean;
  createdAt: number;
}

export interface PublicConfig {
  site: SiteSettings;
  adsense: AdSenseSettings;
  posts: PublicPost[];
}

export const DEFAULT_CONFIG: SiteConfig = {
  version: 1,
  site: {
    name: DEFAULT_SITE_NAME,
    tagline: "Watch what matters, not what's trending",
    metaTitle: `${DEFAULT_SITE_NAME} — Watch what matters, not what's trending`,
    metaDescription:
      "Trendpoptv is a clean, distraction-free video discovery app with AI-curated shelves and a beautiful custom player — built to help you watch less and enjoy more.",
    keywords:
      "trendpoptv, youtube alternative, ai video recommendations, distraction free video player, reduce youtube addiction, minimal video discovery, custom youtube player",
    heroTitle: "Discover",
    heroSubtitle: "Hand-picked picks across tech, science, food, travel and more.",
    aboutText:
      "A clean, distraction-free video discovery app — built to reduce YouTube addiction by replacing the infinite-scroll trap with calm, AI-curated shelves and a beautiful custom player.",
    footerText: `© ${DEFAULT_SITE_NAME}. All rights reserved.`,
    primaryColor: "",
    siteUrl: "https://chiku-tube.vercel.app",
    logoHtml: "",
    logoSrc: "",
  },
  adsense: {
    enabled: false,
    publisherId: "",
    slotHome: "",
    slotWatch: "",
    slotPost: "",
  },
  allowedEmbedHosts: DEFAULT_EMBED_HOSTS,
  posts: [],
};

export const DEFAULT_PUBLIC_CONFIG: PublicConfig = toPublicConfig(DEFAULT_CONFIG);

// ───────────────────────── limits ─────────────────────────
export const LIMITS = {
  posts: 500,
  title: 140,
  category: 60,
  description: 2000,
  embedHtml: 4000,
  shortText: 200,
  longText: 1000,
  hosts: 60,
};

// ───────────────────────── small helpers ─────────────────────────
function str(v: unknown, max: number): string {
  if (typeof v !== "string") return "";
  // strip control characters (keep \n and \t), trim, cap length
  // eslint-disable-next-line no-control-regex
  return v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, max);
}

function bool(v: unknown, fallback = false): boolean {
  return typeof v === "boolean" ? v : fallback;
}

function escapeAttr(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#0*39;/g, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

/** Parse the attributes of a single opening tag string (the part after the tag name). */
function parseAttrs(raw: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw)) !== null) {
    const name = m[1].toLowerCase();
    if (name in out) continue;
    out[name] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? "");
  }
  return out;
}

export function hostAllowed(hostname: string, allowed: string[]): boolean {
  const h = hostname.toLowerCase();
  return allowed.some((a) => h === a || h.endsWith(`.${a}`));
}

// ───────────────────────── embed sanitisers ─────────────────────────
export type ParseResult<T> = ({ ok: true; ignoredExtra: boolean } & T) | { ok: false; error: string };

/**
 * Extract ONE <iframe> from pasted embed HTML and rebuild it from scratch.
 * Everything else in the pasted markup (scripts, handlers, styles, other
 * elements, extra attributes) is discarded. Only https sources on allowed
 * hosts are accepted.
 */
export function parseIframeEmbed(
  html: string,
  allowedHosts: string[],
): ParseResult<{ src: string; title: string; canonical: string }> {
  const input = (html ?? "").trim();
  if (!input) return { ok: false, error: "Paste the video's HTML embed code (an <iframe …> tag)." };
  if (input.length > LIMITS.embedHtml) return { ok: false, error: "Embed code is too long." };

  const m = /<iframe\b([^>]*)>/i.exec(input);
  if (!m) return { ok: false, error: "No <iframe> tag found. Paste the HTML embed code from your video host." };

  const attrs = parseAttrs(m[1]);
  let rawSrc = (attrs["src"] ?? "").trim();
  if (!rawSrc) return { ok: false, error: "The <iframe> has no src attribute." };
  if (rawSrc.startsWith("//")) rawSrc = `https:${rawSrc}`;

  let url: URL;
  try {
    url = new URL(rawSrc);
  } catch {
    return { ok: false, error: "The iframe src is not a valid URL." };
  }
  if (url.protocol !== "https:") return { ok: false, error: "The iframe src must start with https://." };
  if (url.username || url.password) return { ok: false, error: "The iframe src must not contain credentials." };
  if (!hostAllowed(url.hostname, allowedHosts)) {
    return {
      ok: false,
      error: `“${url.hostname}” is not in your allowed embed hosts. Add it under Settings → Allowed embed hosts first.`,
    };
  }

  const title = str(attrs["title"], 120) || "Video player";
  const src = url.toString();
  const canonical = `<iframe src="${escapeAttr(src)}" title="${escapeAttr(title)}" allowfullscreen></iframe>`;
  const rest = input.replace(/<iframe\b[^>]*>[\s\S]*?<\/iframe\s*>/i, "").replace(/<iframe\b[^>]*>/i, "").trim();
  return { ok: true, src, title, canonical, ignoredExtra: rest.length > 0 };
}

/**
 * Extract ONE <img> from pasted HTML and rebuild it. Accepts https URLs and
 * same-site absolute paths (e.g. /thumbs/a.jpg). data:/javascript: are refused.
 */
export function parseImgEmbed(html: string): ParseResult<{ src: string; alt: string; canonical: string }> {
  const input = (html ?? "").trim();
  if (!input) return { ok: false, error: "Paste the thumbnail's HTML embed code (an <img …> tag)." };
  if (input.length > LIMITS.embedHtml) return { ok: false, error: "Thumbnail code is too long." };

  const m = /<img\b([^>]*)>/i.exec(input);
  if (!m) return { ok: false, error: "No <img> tag found. Paste the image's HTML embed code." };

  const attrs = parseAttrs(m[1]);
  let rawSrc = (attrs["src"] ?? attrs["data-src"] ?? "").trim();
  if (!rawSrc) return { ok: false, error: "The <img> has no src attribute." };
  if (rawSrc.startsWith("//")) rawSrc = `https:${rawSrc}`;

  let src: string;
  if (/^\/(?!\/)/.test(rawSrc)) {
    if (/[\u0000-\u001F\\]/.test(rawSrc)) return { ok: false, error: "Invalid image path." };
    src = rawSrc;
  } else {
    let url: URL;
    try {
      url = new URL(rawSrc);
    } catch {
      return { ok: false, error: "The image src is not a valid URL." };
    }
    if (url.protocol !== "https:") return { ok: false, error: "The image src must start with https://." };
    if (url.username || url.password) return { ok: false, error: "The image src must not contain credentials." };
    src = url.toString();
  }

  const alt = str(attrs["alt"], 140);
  const canonical = `<img src="${escapeAttr(src)}" alt="${escapeAttr(alt)}">`;
  const rest = input.replace(/<img\b[^>]*>/i, "").replace(/<\/?a\b[^>]*>/gi, "").trim();
  return { ok: true, src, alt, canonical, ignoredExtra: rest.length > 0 };
}

// ───────────────────────── field validators ─────────────────────────
export function normalizePublisherId(v: unknown): string {
  const s = str(v, 40).toLowerCase();
  if (/^ca-pub-\d{10,20}$/.test(s)) return s;
  if (/^pub-\d{10,20}$/.test(s)) return `ca-${s}`;
  return "";
}

export function normalizeSlot(v: unknown): string {
  const s = str(v, 30);
  return /^\d{6,20}$/.test(s) ? s : "";
}

function normalizeColor(v: unknown): string {
  const s = str(v, 7);
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : "";
}

function normalizeSiteUrl(v: unknown, fallback: string): string {
  const s = str(v, 200).replace(/\/+$/, "");
  if (!s) return fallback;
  try {
    const u = new URL(s);
    if (u.protocol !== "https:" && u.protocol !== "http:") return fallback;
    return u.origin;
  } catch {
    return fallback;
  }
}

function normalizeHosts(v: unknown): string[] {
  if (!Array.isArray(v)) return DEFAULT_EMBED_HOSTS;
  const out: string[] = [];
  for (const raw of v) {
    const h = str(raw, 100)
      .toLowerCase()
      .replace(/^https?:\/\//, "")
      .replace(/\/.*$/, "")
      .replace(/^www\./, "");
    if (/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(h) && !out.includes(h)) out.push(h);
    if (out.length >= LIMITS.hosts) break;
  }
  return out;
}

function newId(): string {
  const c = (globalThis as { crypto?: { randomUUID?: () => string } }).crypto;
  const base = c?.randomUUID ? c.randomUUID() : `${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`;
  return base.replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 12);
}

// ───────────────────────── full-config sanitiser ─────────────────────────
export interface SanitizeOutcome {
  config: SiteConfig;
  errors: string[];
  warnings: string[];
}

/**
 * Turn untrusted input (admin PUT body, or whatever is in storage) into a
 * valid SiteConfig. `errors` blocks saving; `warnings` are informational.
 */
export function sanitizeConfig(input: unknown): SanitizeOutcome {
  const errors: string[] = [];
  const warnings: string[] = [];
  const raw = (input && typeof input === "object" ? input : {}) as Record<string, unknown>;
  const rs = (raw.site && typeof raw.site === "object" ? raw.site : {}) as Record<string, unknown>;
  const ra = (raw.adsense && typeof raw.adsense === "object" ? raw.adsense : {}) as Record<string, unknown>;
  const d = DEFAULT_CONFIG;

  const allowedEmbedHosts = normalizeHosts(raw.allowedEmbedHosts);

  const pick = (key: keyof SiteSettings, max: number): string => {
    const v = rs[key];
    return typeof v === "string" ? str(v, max) : (d.site[key] as string);
  };

  // logo
  const logoRaw = typeof rs.logoHtml === "string" ? rs.logoHtml.trim() : "";
  let logoHtml = "";
  let logoSrc = "";
  if (logoRaw) {
    const r = parseImgEmbed(logoRaw);
    if (r.ok) {
      logoHtml = r.canonical;
      logoSrc = r.src;
    } else errors.push(`Logo: ${r.error}`);
  }

  const name = str(rs.name, 40) || d.site.name;
  const site: SiteSettings = {
    name,
    tagline: pick("tagline", LIMITS.shortText),
    metaTitle: pick("metaTitle", 120),
    metaDescription: pick("metaDescription", 320),
    keywords: pick("keywords", 400),
    heroTitle: pick("heroTitle", 80) || d.site.heroTitle,
    heroSubtitle: pick("heroSubtitle", LIMITS.shortText),
    aboutText: pick("aboutText", LIMITS.longText),
    footerText: pick("footerText", LIMITS.shortText),
    primaryColor: normalizeColor(rs.primaryColor),
    siteUrl: normalizeSiteUrl(rs.siteUrl, d.site.siteUrl),
    logoHtml,
    logoSrc,
  };
  if (typeof rs.primaryColor === "string" && rs.primaryColor.trim() && !site.primaryColor) {
    errors.push("Theme colour must look like #7c3aed.");
  }

  // adsense
  const publisherId = normalizePublisherId(ra.publisherId);
  if (typeof ra.publisherId === "string" && ra.publisherId.trim() && !publisherId) {
    errors.push("AdSense publisher ID must look like ca-pub-1234567890123456.");
  }
  const slot = (key: string): string => {
    const v = ra[key];
    const n = normalizeSlot(v);
    if (typeof v === "string" && v.trim() && !n) errors.push(`AdSense slot “${key}” must be a number (6–20 digits).`);
    return n;
  };
  const adsense: AdSenseSettings = {
    enabled: bool(ra.enabled),
    publisherId,
    slotHome: slot("slotHome"),
    slotWatch: slot("slotWatch"),
    slotPost: slot("slotPost"),
  };
  if (adsense.enabled && !publisherId) {
    errors.push("AdSense is switched on but the publisher ID is missing.");
  }

  // posts
  let siteHost = "";
  try {
    siteHost = new URL(site.siteUrl).hostname.toLowerCase();
  } catch {
    /* ignore */
  }
  const rawPosts = Array.isArray(raw.posts) ? raw.posts : [];
  if (rawPosts.length > LIMITS.posts) errors.push(`Too many posts (max ${LIMITS.posts}).`);
  const seen = new Set<string>();
  const posts: Post[] = [];
  for (const item of rawPosts.slice(0, LIMITS.posts)) {
    const p = (item && typeof item === "object" ? item : {}) as Record<string, unknown>;
    const title = str(p.title, LIMITS.title);
    const label = title || "Untitled post";
    if (!title) errors.push("A post is missing its title.");

    let id = str(p.id, 40).toLowerCase();
    if (!/^[a-z0-9-]{4,40}$/.test(id) || seen.has(id)) id = newId();
    seen.add(id);

    const e = parseIframeEmbed(typeof p.embedHtml === "string" ? p.embedHtml : "", allowedEmbedHosts);
    const t = parseImgEmbed(typeof p.thumbnailHtml === "string" ? p.thumbnailHtml : "");
    if (e.ok && siteHost && new URL(e.src).hostname.toLowerCase() === siteHost) {
      // An iframe on our own origin with allow-scripts + allow-same-origin could escape its sandbox.
      errors.push(`Post “${label}” — video: embeds from this site's own domain are not allowed.`);
    } else if (!e.ok) errors.push(`Post “${label}” — video: ${e.error}`);
    else if (e.ignoredExtra) warnings.push(`Post “${label}”: extra markup around the iframe was removed.`);
    if (!t.ok) errors.push(`Post “${label}” — thumbnail: ${t.error}`);
    else if (t.ignoredExtra) warnings.push(`Post “${label}”: extra markup around the thumbnail <img> was removed.`);

    const createdAt = typeof p.createdAt === "number" && Number.isFinite(p.createdAt) ? p.createdAt : Date.now();
    posts.push({
      id,
      title,
      category: str(p.category, LIMITS.category),
      description: str(p.description, LIMITS.description),
      embedHtml: e.ok ? e.canonical : "",
      thumbnailHtml: t.ok ? t.canonical : "",
      embedSrc: e.ok ? e.src : "",
      embedTitle: e.ok ? e.title : "",
      thumbnailSrc: t.ok ? t.src : "",
      published: bool(p.published, true),
      featured: bool(p.featured),
      createdAt,
    });
  }

  return {
    config: { version: 1, site, adsense, allowedEmbedHosts, posts },
    errors,
    warnings,
  };
}

/**
 * Strip a stored config down to what visitors may see. Posts whose derived
 * fields are missing are skipped, so a bad record can never reach the page.
 */
export function toPublicConfig(c: SiteConfig): PublicConfig {
  const posts: PublicPost[] = c.posts
    .filter((p) => p.published && p.embedSrc && p.thumbnailSrc)
    .sort((a, b) => Number(b.featured) - Number(a.featured) || b.createdAt - a.createdAt)
    .map((p) => ({
      id: p.id,
      title: p.title,
      category: p.category,
      description: p.description,
      embedSrc: p.embedSrc,
      embedTitle: p.embedTitle,
      thumbnailSrc: p.thumbnailSrc,
      featured: p.featured,
      createdAt: p.createdAt,
    }));
  return { site: c.site, adsense: c.adsense, posts };
}

/** True when AdSense should be active for visitors. */
export function adsenseActive(a: AdSenseSettings): boolean {
  return a.enabled && /^ca-pub-\d{10,20}$/.test(a.publisherId);
}

/** Build the ads.txt body for a publisher id. */
export function buildAdsTxt(publisherId: string): string {
  const id = publisherId.replace(/^ca-/, "");
  return `google.com, ${id}, DIRECT, f08c47fec0942fa0\n`;
}
