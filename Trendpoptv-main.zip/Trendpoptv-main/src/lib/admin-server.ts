// Trendpoptv — server-only admin helpers.
// Imported ONLY from server function handlers and API route handlers, so it is
// never bundled for the browser. No third-party dependencies: Web Crypto +
// fetch (Upstash Redis REST API) only.

import { DEFAULT_CONFIG, sanitizeConfig, toPublicConfig, type PublicConfig, type SiteConfig } from "./site-config";

// ───────────────────────── environment ─────────────────────────
//   ADMIN_PASSWORD         required, 12+ chars
//   ADMIN_SESSION_SECRET   required, 32+ random chars (signs the login cookie)
//   UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN   (or the KV_REST_API_* names
//                          that the Vercel ↔ Upstash integration creates)

// Local declaration: tsconfig restricts `types` to vite/client, so Node's
// global `process` is not otherwise known to the type-checker.
declare const process: { env: Record<string, string | undefined> } | undefined;

function env(name: string): string {
  return (typeof process !== "undefined" && process.env[name]) || "";
}

export function adminConfigured(): { ok: true } | { ok: false; reason: string } {
  const pw = env("ADMIN_PASSWORD");
  const secret = env("ADMIN_SESSION_SECRET");
  if (pw.length < 12) return { ok: false, reason: "ADMIN_PASSWORD is not set (or shorter than 12 characters)." };
  if (secret.length < 32) return { ok: false, reason: "ADMIN_SESSION_SECRET is not set (or shorter than 32 characters)." };
  return { ok: true };
}

function redisEnv(): { url: string; token: string } | null {
  const url = env("UPSTASH_REDIS_REST_URL") || env("KV_REST_API_URL");
  const token = env("UPSTASH_REDIS_REST_TOKEN") || env("KV_REST_API_TOKEN");
  return url && token ? { url: url.replace(/\/+$/, ""), token } : null;
}

export function storageConfigured(): boolean {
  return redisEnv() !== null;
}

// ───────────────────────── Redis (REST) ─────────────────────────
async function redis<T = unknown>(command: (string | number)[]): Promise<T | null> {
  const cfg = redisEnv();
  if (!cfg) throw new Error("Storage is not configured.");
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 6000);
  try {
    const res = await fetch(cfg.url, {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.token}`, "Content-Type": "application/json" },
      body: JSON.stringify(command),
      signal: ctl.signal,
      cache: "no-store",
    });
    if (!res.ok) throw new Error(`Storage error (${res.status}).`);
    const json = (await res.json()) as { result?: T; error?: string };
    if (json.error) throw new Error("Storage rejected the request.");
    return json.result ?? null;
  } finally {
    clearTimeout(timer);
  }
}

// ───────────────────────── config storage ─────────────────────────
const CONFIG_KEY = "trendpoptv:config:v1";
const CACHE_MS = 15_000;
let cache: { at: number; config: SiteConfig } | null = null;

/** Read the stored config. Never throws: falls back to defaults so the public site stays up. */
export async function loadConfig(fresh = false): Promise<SiteConfig> {
  if (!fresh && cache && Date.now() - cache.at < CACHE_MS) return cache.config;
  let config = DEFAULT_CONFIG;
  if (storageConfigured()) {
    try {
      const raw = await redis<string>(["GET", CONFIG_KEY]);
      if (typeof raw === "string" && raw) {
        // Re-sanitise on read: stored data is not blindly trusted either.
        config = sanitizeConfig(JSON.parse(raw)).config;
      }
    } catch (e) {
      console.error("[trendpoptv] loadConfig failed:", (e as Error).message);
      if (cache && !fresh) return cache.config; // serve last good copy
      if (fresh) throw e; // the admin must know the read failed, not see defaults
    }
  }
  cache = { at: Date.now(), config };
  return config;
}

export async function loadPublicConfig(): Promise<PublicConfig> {
  return toPublicConfig(await loadConfig());
}

export async function saveConfig(config: SiteConfig): Promise<void> {
  const json = JSON.stringify(config);
  if (json.length > 900_000) throw new Error("Configuration is too large to save.");
  await redis(["SET", CONFIG_KEY, json]);
  cache = { at: Date.now(), config };
}

// ───────────────────────── crypto helpers ─────────────────────────
const enc = new TextEncoder();

async function hmacBytes(secret: string, message: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, [
    "sign",
  ]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, enc.encode(message)));
}

function toHex(b: Uint8Array): string {
  return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
}

function bytesEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

/** Constant-time string comparison (hashes both sides first so length does not leak). */
async function safeEqual(a: string, b: string): Promise<boolean> {
  const k = env("ADMIN_SESSION_SECRET") || "k";
  return bytesEqual(await hmacBytes(k, `eq:${a}`), await hmacBytes(k, `eq:${b}`));
}

export async function checkPassword(candidate: string): Promise<boolean> {
  const expected = env("ADMIN_PASSWORD");
  if (!expected || typeof candidate !== "string" || candidate.length > 512) return false;
  return safeEqual(candidate, expected);
}

// ───────────────────────── session cookie ─────────────────────────
const SESSION_SECONDS = 60 * 60 * 8; // 8 hours

function isHttps(request: Request): boolean {
  const proto = request.headers.get("x-forwarded-proto");
  if (proto) return proto.split(",")[0].trim() === "https";
  return new URL(request.url).protocol === "https:";
}

function cookieName(request: Request): string {
  // __Host- prefix = browser enforces Secure + Path=/ + no Domain.
  return isHttps(request) ? "__Host-tp_admin" : "tp_admin";
}

export async function createSessionCookie(request: Request): Promise<string> {
  const exp = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const nonce = toHex(crypto.getRandomValues(new Uint8Array(12)));
  const payload = `${exp}.${nonce}`;
  const sig = toHex(await hmacBytes(env("ADMIN_SESSION_SECRET"), `session:${payload}`));
  const attrs = [`Path=/`, `HttpOnly`, `SameSite=Strict`, `Max-Age=${SESSION_SECONDS}`];
  if (isHttps(request)) attrs.push("Secure");
  return `${cookieName(request)}=${payload}.${sig}; ${attrs.join("; ")}`;
}

export function clearSessionCookie(request: Request): string {
  const attrs = [`Path=/`, `HttpOnly`, `SameSite=Strict`, `Max-Age=0`];
  if (isHttps(request)) attrs.push("Secure");
  return `${cookieName(request)}=; ${attrs.join("; ")}`;
}

function readCookie(request: Request, name: string): string {
  const header = request.headers.get("cookie") || "";
  for (const part of header.split(";")) {
    const i = part.indexOf("=");
    if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return "";
}

export async function isAuthenticated(request: Request): Promise<boolean> {
  if (!adminConfigured().ok) return false;
  const token = readCookie(request, cookieName(request));
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [expStr, nonce, sig] = parts;
  const exp = Number(expStr);
  if (!Number.isFinite(exp) || exp < Math.floor(Date.now() / 1000)) return false;
  if (!/^[a-f0-9]{24}$/.test(nonce) || !/^[a-f0-9]{64}$/.test(sig)) return false;
  const expected = toHex(await hmacBytes(env("ADMIN_SESSION_SECRET"), `session:${expStr}.${nonce}`));
  return safeEqual(sig, expected);
}

// ───────────────────────── CSRF / origin guard ─────────────────────────
/** State-changing requests must come from this site's own pages. */
export function sameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return false;
  let originHost: string;
  try {
    originHost = new URL(origin).host;
  } catch {
    return false;
  }
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host") || new URL(request.url).host;
  return originHost.toLowerCase() === host.split(",")[0].trim().toLowerCase();
}

// ───────────────────────── login throttling ─────────────────────────
const MAX_ATTEMPTS = 8;
const WINDOW_SECONDS = 15 * 60;
const memAttempts = new Map<string, { count: number; resetAt: number }>();

export function clientIp(request: Request): string {
  const xff = request.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim().slice(0, 64);
  return (request.headers.get("x-real-ip") || "unknown").slice(0, 64);
}

/** Returns true when this attempt is allowed. Counts every attempt. */
export async function allowLoginAttempt(ip: string): Promise<boolean> {
  const key = `trendpoptv:rl:login:${ip.replace(/[^a-zA-Z0-9:._-]/g, "_")}`;
  if (storageConfigured()) {
    try {
      const n = await redis<number>(["INCR", key]);
      if (n === 1) await redis(["EXPIRE", key, WINDOW_SECONDS]);
      return (n ?? 1) <= MAX_ATTEMPTS;
    } catch {
      /* fall through to in-memory limiter */
    }
  }
  const now = Date.now();
  const rec = memAttempts.get(key);
  if (!rec || rec.resetAt < now) {
    memAttempts.set(key, { count: 1, resetAt: now + WINDOW_SECONDS * 1000 });
    return true;
  }
  rec.count++;
  return rec.count <= MAX_ATTEMPTS;
}

export async function clearLoginAttempts(ip: string): Promise<void> {
  const key = `trendpoptv:rl:login:${ip.replace(/[^a-zA-Z0-9:._-]/g, "_")}`;
  memAttempts.delete(key);
  if (storageConfigured()) {
    try {
      await redis(["DEL", key]);
    } catch {
      /* ignore */
    }
  }
}

// ───────────────────────── response helpers ─────────────────────────
export function json(body: unknown, status = 200, extraHeaders: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      ...extraHeaders,
    },
  });
}

export async function readJsonBody(request: Request, maxChars = 700_000): Promise<unknown> {
  const text = await request.text();
  if (text.length > maxChars) throw new Error("Request body too large.");
  return JSON.parse(text);
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
