import { createServerFn } from "@tanstack/react-start";
import { loadPublicConfig } from "./admin-server";

/**
 * Public site configuration (theme text, AdSense ids, published posts).
 * Contains nothing secret: unpublished posts and admin-only fields are
 * stripped by toPublicConfig() before anything leaves the server.
 */
export const getSiteConfig = createServerFn({ method: "GET" }).handler(async () => {
  return await loadPublicConfig();
});
