import { useLoaderData } from "@tanstack/react-router";
import { DEFAULT_PUBLIC_CONFIG, DEFAULT_SITE_NAME, type PublicConfig } from "./site-config";

/** Public site config (theme text, AdSense ids, published posts) from the root route loader. */
export function useSiteConfig(): PublicConfig {
  const data = useLoaderData({ from: "__root__" }) as { config?: PublicConfig } | undefined;
  return data?.config ?? DEFAULT_PUBLIC_CONFIG;
}

/**
 * For child-route `head()` functions: read the public config from the root
 * match's loader data (falls back to defaults if unavailable).
 */
export function configFromHead(ctx: unknown): PublicConfig {
  const matches = (ctx as { matches?: Array<{ loaderData?: { config?: PublicConfig } }> } | undefined)?.matches;
  return matches?.[0]?.loaderData?.config ?? DEFAULT_PUBLIC_CONFIG;
}

export function siteNameFromHead(ctx: unknown): string {
  return configFromHead(ctx).site?.name || DEFAULT_SITE_NAME;
}
