import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Play } from "lucide-react";
import { useState } from "react";
import type { PublicPost } from "@/lib/site-config";

/** Card for an admin-published post. Thumbnail comes from the sanitised <img> embed. */
export function PostCard({ post, index = 0 }: { post: PublicPost; index?: number }) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(index, 8) * 0.03, ease: "easeOut" }}
      className="group"
    >
      <Link
        to="/post"
        search={{ id: post.id }}
        className="block rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <div className="relative aspect-video overflow-hidden rounded-2xl bg-muted shadow-soft transition-shadow group-hover:shadow-elevated">
          {!loaded && !failed && <div className="thumb-blur absolute inset-0" />}
          {!failed && (
            <img
              src={post.thumbnailSrc}
              alt={post.title}
              loading="lazy"
              decoding="async"
              referrerPolicy="no-referrer"
              onLoad={() => setLoaded(true)}
              onError={() => setFailed(true)}
              className={`absolute inset-0 h-full w-full object-cover transition-all duration-500 group-hover:scale-[1.03] ${
                loaded ? "opacity-100" : "opacity-0"
              }`}
            />
          )}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity group-hover:opacity-100">
            <div className="rounded-full bg-primary/90 p-3 text-primary-foreground shadow-elevated">
              <Play className="h-5 w-5 fill-current" />
            </div>
          </div>
        </div>
        <div className="mt-3 px-1">
          <h3
            className="line-clamp-2 text-[15px] font-medium leading-snug text-foreground transition-colors group-hover:text-primary"
            style={{ fontFamily: "var(--font-sans)" }}
          >
            {post.title}
          </h3>
          {post.category && <p className="mt-1 text-xs text-muted-foreground">{post.category}</p>}
        </div>
      </Link>
    </motion.div>
  );
}
