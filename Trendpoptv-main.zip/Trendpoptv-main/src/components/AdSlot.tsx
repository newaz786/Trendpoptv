import { useEffect, useRef } from "react";
import { useSiteConfig } from "@/lib/use-site";
import { adsenseActive } from "@/lib/site-config";

type Placement = "home" | "watch" | "post";

/**
 * One responsive AdSense display unit. Renders nothing unless AdSense is
 * enabled in the admin panel AND a valid slot id is saved for this placement.
 * The AdSense script itself is loaded once from the root route's <head>.
 */
export function AdSlot({ placement, className }: { placement: Placement; className?: string }) {
  const { adsense } = useSiteConfig();
  const ref = useRef<HTMLModElement>(null);
  const slot =
    placement === "home" ? adsense.slotHome : placement === "watch" ? adsense.slotWatch : adsense.slotPost;
  const active = adsenseActive(adsense) && !!slot;

  useEffect(() => {
    const el = ref.current;
    if (!active || !el || el.getAttribute("data-adsbygoogle-status")) return;
    try {
      const w = window as unknown as { adsbygoogle?: unknown[] };
      (w.adsbygoogle = w.adsbygoogle || []).push({});
    } catch {
      /* ad blockers / script not loaded — ignore */
    }
  }, [active, slot, adsense.publisherId]);

  if (!active) return null;
  return (
    <div className={className ?? "my-6 overflow-hidden text-center"} aria-label="Advertisement">
      <ins
        key={`${adsense.publisherId}-${slot}`}
        ref={ref}
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client={adsense.publisherId}
        data-ad-slot={slot}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}
