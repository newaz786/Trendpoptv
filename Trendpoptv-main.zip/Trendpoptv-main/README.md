


<p align="center">
  <img src="public/chiku.png" alt="Trendpoptv Logo" width="350"/>
</p>

> A calmer way to watch. **Made to reduce YouTube addiction** — not feed it.

Trendpoptv is a distraction-free, AI-powered video discovery app. No
endless infinite scroll. No autoplay traps. No notifications screaming
for your attention. Just a clean player, hand-picked shelves, and a
"Continue Watching" row so you can finish the one video you came for and
**actually close the tab**.

---

## Why this exists

YouTube is brilliant at one thing: keeping you watching. Recommendations,
shorts, autoplay, banners, comments — every pixel is engineered to extend
session time.

Trendpoptv flips the goal:

- **Watch what you came for, leave when you're done.**
- No suggested rabbit holes after every video.
- No comments, no shorts, no live notifications.
- AI is used to *help you find one good thing*, not to keep you scrolling.
- Your watch history lives in *your browser* — no cross-device profile
  building, no ad targeting.

If you've ever opened YouTube to play one song and looked up an hour later
wondering where the time went, this is for you.

---

## Features

- 🎯 **AI-personalized "Discover"** — suggests search phrases based on
  your taste, in your language. With a deterministic fallback so the feed
  is *never* empty.
- ▶️ **Continue Watching** — pick up videos you didn't finish.
- 🔥 **Trending Now** — refreshed every 10 minutes.
- 🎶 **Mood chips** — Lofi, Tech, Gaming, Cooking, Travel, Comedy, Learn,
  Podcasts, Documentary in one tap.
- ❤️ **Liked Picks** — a curated row of fresh videos based on what you
  loved.
- 🕘 **Watch Again** — revisit recent finishes.
- 🎬 **Persistent custom player** — never restarts when you navigate.
  - Double-tap to seek ±10s
  - Keyboard shortcuts (space, ←/→, m, f)
  - Speed control 0.5×–2×
  - Picture-in-picture style **mini player** when you leave /watch
  - Background-friendly: MediaSession metadata in the OS notification
  - Download button for offline keeping
- 🛡️ **Self-healing stream layer** — broken/expired stream URLs are
  auto-retried once, then quietly hidden from every shelf.
- 💾 **History-keyed cache** — recommendations persist across reloads,
  navigation is instant.
- 🌗 **Dark UI**, soft motion, semantic design tokens.
- 📱 Mobile-first with a bottom tab bar.

---

## Tech stack

- **Framework**: TanStack Start v1 (React 19 + Vite 7, SSR-ready)
- **Routing**: file-based, type-safe (`src/routes/`)
- **State**: Zustand with `localStorage` persistence
- **Styling**: Tailwind CSS v4 + custom design tokens (`src/styles.css`)
- **Deploy target**: Cloudflare Workers (edge) — also runs on Vercel and
  any Node 18+ host.

---

## Getting started

```bash
# Install
bun install     # or: npm install / pnpm install

# Run dev server (http://localhost:8080)
bun run dev

# Type-check + production build
bun run build

# Preview the build
bun run preview
```

### Environment

The public site needs no secrets. Watch history and likes live in the visitor's
`localStorage`. The **admin panel** (below) needs the variables listed in
`.env.example`.

---

## Deployment

### Cloudflare Workers

`wrangler.jsonc` is preconfigured. Build then deploy:

```bash
bun run build
npx wrangler deploy
```

The build outputs an SSR worker plus static assets. Make sure the
`nodejs_compat` flag is enabled (already set in `wrangler.jsonc`).

### Vercel

`vercel.json` targets the Vercel adapter. Connect the repo on
[vercel.com](https://vercel.com), then:

```bash
bun run build:vercel
```

Vercel will run the same command on push.

### Self-host (Node)

```bash
bun run build
node .output/server/index.mjs
```

Any Node-18+ host works (Fly.io, Railway, your own VPS, a Raspberry Pi
on your home network).

### Docker (optional sketch)

```dockerfile
FROM oven/bun:1 AS build
WORKDIR /app
COPY package.json bun.lockb ./
RUN bun install --frozen-lockfile
COPY . .
RUN bun run build

FROM node:20-alpine
WORKDIR /app
COPY --from=build /app/.output ./.output
EXPOSE 3000
CMD ["node", ".output/server/index.mjs"]
```

---



## Admin panel (`/admin`)

A private panel, usable only by you, to manage:

- **Videos** — add/edit/hide/delete posts. The video is a pasted HTML `<iframe>`
  embed code and the thumbnail is a pasted HTML `<img>` code. Only the iframe /
  image URL is kept; everything else in the paste is discarded, and iframes are
  only accepted from the hosts you allow (Settings tab).
- **Theme text** — site name, headings, About text, footer, SEO title /
  description / keywords, accent colour, optional logo (`<img>` embed code).
- **AdSense** — publisher ID, three ad-slot IDs, on/off. `/ads.txt` is generated
  for you.

### One-time setup (Vercel)

1. Vercel → *Storage* / *Marketplace* → add **Upstash Redis** and connect it to
   the project (this creates the `KV_REST_API_*` / `UPSTASH_REDIS_REST_*` variables).
2. Add `ADMIN_PASSWORD` (12+ chars) and `ADMIN_SESSION_SECRET` (32+ random chars,
   e.g. `openssl rand -base64 48`) under *Settings → Environment Variables*.
3. Redeploy, then open `https://your-domain/admin`.

### Security model

- Password + signed, `HttpOnly`, `SameSite=Strict`, `Secure` session cookie (8 h).
- Every change is re-validated on the server; the browser is never trusted.
- Same-origin check on all state-changing requests (CSRF); 8 attempts / 15 min / IP.
- `/admin` is `noindex` and disallowed in `robots.txt`.
- Visitors only ever receive published posts and sanitised URLs — no raw HTML.

## Privacy & data

- **Watch history, likes, position memory** → `localStorage` only.
- **We Use Your ip address for showing content according to your language  but we don't save it **
- **No analytics, no trackers, no third-party scripts.**

You can wipe everything in one click via your browser's site-data
settings.

---


## 👩‍💻 Creators

<table width="100%">
    <tr>
      <td align="center" width="50%">
        <img src="https://random-images-anya.vercel.app/anya" width="260"><br><br>
        <b>𝜜ɴყꫝㅤ𓆩💗𓆪</b><br><br>
        <a href="https://github.com/itz-Anya">
          <img src="https://img.shields.io/badge/GitHub-Anya-black?style=for-the-badge&logo=github">
        </a>
      </td>
      <td align="center" width="50%">
        <img src="https://itz-murali-images.vercel.app/api" width="260"><br><br>
        <b>𝐌 𝐔 𝐑 𝚨 𝐋 𝐈 𓂃ִֶָ⋆.˚</b><br><br>
        <a href="https://github.com/Itz-Murali">
          <img src="https://img.shields.io/badge/GitHub-Itz--Murali-black?style=for-the-badge&logo=github">
        </a>
      </td>
    </tr>
  </table>


---

<p align="center">
⭐ If you like this project, don’t forget to star the repo!
</p> 
